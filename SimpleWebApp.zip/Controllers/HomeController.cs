using Microsoft.AspNetCore.Mvc;

namespace SimpleWebApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index() => Content("✅ Hello from Azure Web App!");
    }
}